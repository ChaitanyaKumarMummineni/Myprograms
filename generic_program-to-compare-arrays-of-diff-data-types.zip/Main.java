/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class myclass<T extends Comparable<T>>
{
    T []vals;
    myclass(T []x)
    {
        vals=x;
    }
    public T min()
    {
        T v=vals[0];
        for(int i=1;i<vals.length;i++)
        {
            if(vals[i].compareTo(v)<0)
            {
                v=vals[i];
            }
        }
         return v;
    }
    public T max()
    {
        T v=vals[0];
        for(int i=1;i<vals.length;i++)
        {
            if(vals[i].compareTo(v)>0)
            {
                v=vals[i];
            }
        }
        return v;
    }
    
}
public class Main{
    public static void main(String args[])
    {
        Integer[]ints={1,2,3,4,5,6,43,53};
        Character[]chars={'h','l','o','m','t'};
        Double[]db={3.3,4.4,5.6,4.7,8.8};
        myclass<Integer>i=new myclass<Integer>(ints);
        myclass<Character>c=new myclass<Character>(chars);
        myclass<Double>d=new myclass<Double>(db);
        System.out.println("max in ints: "+i.max());
        System.out.println("min in ints: "+i.min());
        System.out.println("max in chars: "+c.max());
        System.out.println("min in chars: "+c.min());
        System.out.println("max in db: "+d.max());
        System.out.println("min in db: "+d.min());
        
        
    
    }
}