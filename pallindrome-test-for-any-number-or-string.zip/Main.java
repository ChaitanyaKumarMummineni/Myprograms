/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
		String original,rev="";
		Scanner sc=new Scanner(System.in);
		original=sc.nextLine();
		int len=original.length();
		for(int i=len-1;i>=0;i--)
		{
		    rev=rev+original.charAt(i);
		}
		if (original.equals(rev))
		{
		    System.out.println("It is a pallindrome");
		}
		else System.out.println("It is not a pallindrome");
	}
}
