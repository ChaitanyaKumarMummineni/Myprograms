/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
   int data=8,i;
    int a[8]={6,7,5,4,3,2,1,8};
   printf("Enter the element to be searched: %d\n",data);
  
   for( i=0;i<8;i++)
   {
     if(a[i]==data)
     {
         printf("The element is found at index: %d ",i);
         break;
     }
   }
   if(i==8)
   {
       printf("The element is not found");
   }
    return 0;
}
