/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define N 20
#define M 3 
int main(){
    int r[N]={1,1,1,7,4,2,6,8,7,6,3,5,1,7,3,1,7,5,3,5};
    int frame[M];
    int page_fault=0,page_hit=0,top=0,flag=0;
    for(int i=0; i<M; i++){
        frame[i]=-1;
    }
    for(int i=0; i<N; i++){
        flag=0;
        for(int j=0; j<M; j++){
            if(r[i]==frame[j]){
                flag=1;
                page_hit++;
                break;
            }
        }
        if(flag==0){
            page_fault++;
            frame[top%M]=r[i];
            top++;
        }
    }
    printf("No. of Page Hits = %d\n",page_hit);
    printf("No. of Page Faults = %d",page_fault);
}