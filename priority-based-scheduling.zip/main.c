/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
struct pcb{
    int pid,bt,prior,tat;
};

int main()
{
    int i,j,n;
    float sum=0,avg=0;
    struct pcb p[10],temp;
    printf("Enter the number of processes:\n");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        printf("Enter the bt and priority of the processes:\n");
        scanf("%d%d",&p[i].bt,&p[i].prior);
        p[i].pid=i+1;
    }
    for(i=0;i<n-1;i++)
    {
        for(j=0;j<=n-i-1;j++)
        {
            if(p[j].prior>p[j+1].prior)
            {
                temp=p[j];
                p[j]=p[j+1];
                p[j+1]=temp;
            }
        }
    }
    for(i=0;i<n;i++)
    {
        sum=sum+p[i].bt;
        p[i].tat=sum;
    }
    sum=0;
    printf("processId\tBurst time\tpriority\tTurnaround time\n");
    for(i=0;i<n;i++)
    {
        printf("\n%d\t\t%d\t\t%d\t\t%d\n",p[i].pid,p[i].bt,p[i].prior,p[i].tat);
        sum+=p[i].tat;
    }
    avg=sum/(float)n;
    printf("Average turnaround time:%0.3f\n",avg);
    return 0;
}
