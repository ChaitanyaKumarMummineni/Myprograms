#include <iostream> 
#include <string.h> 
using namespace std; 
#define N 10 

int acc,w; 
int d;
int acc1,acc2,t; 
string p1,p2,p; 
int i=1; 

class bank{ 
    public: 
    int acc_no=0; 
    string name; 
    int balance=0; 
    string password; 
    
    void create(){
        acc_no=i;
        cout<<"Enter name :";
        cin>>name;
        cout<<"Enter balance :";
        cin>>balance;
        cout<<"Enter password :";
        cin>>password;
        cout<<endl;
        cout<<"ACCOUNT SUCCESSFULLY CREATED,YOUR ACCOUNT NUMBER IS "<<acc_no<<endl;
        ++i;
    }
    void display(){
        cout<<"Account number :"<<acc_no<<endl;
        cout<<"Name :"<<name<<endl;
        cout<<"Balance :"<<balance<<endl;
        cout<<endl;
    }
    void Delete(){
        acc_no=-1; 
      
        int balance=-1; 
       
        cout<<"DELETION SUCCESSFULL"<<endl;
    }
}; 

int main() 
{ 
    bank b[N],temp; 
    int choice; 
    cout<<"\n                             WELCOME TO HELLO WORLD BANK"<<endl; 
    for(;;){
        cout<<endl;
        cout<<"1. Create account number"<<endl; 
        cout<<"2. Display all accounts"<<endl; 
        cout<<"3. Deposit"<<endl; 
        cout<<"4. Withdraw"<<endl; 
        cout<<"5. Transfer"<<endl; 
        cout<<"6. Display based on account number"<<endl; 
        cout<<"7. Sorting based on balance"<<endl; 
        cout<<"8. Delete account "<<endl; 
        cout<<"9. Exit"<<endl; 
        cout<<endl; 
        cout<<"Enter Choice :"; 
        cin>>choice; 
        cout<<endl;
        switch(choice){ 
            case 1:
            b[i].create(); 
            cout<<endl; 
            break; 
             
            case 2: 
            for(int j=1; j<i; j++){
                if(b[j].acc_no!=-1){
                   cout<<"Customer "<<j<<" details:"<<endl;
                   b[j].display();
                }
            } 
            cout<<endl; 
            break; 
             
            case 3: 
            
            cout<<"Enter your account number to deposit :"; 
            cin>>acc; 
            if(acc<i && acc>0){ 
                cout<<"Enter password :"; 
                cin>>p;
                if(p==b[acc].password){ 
                    cout<<"Enter amount to be deposited :"; 
                    cin>>d; 
                    b[acc].balance+=d; 
                    cout<<"Your current balance is "<<b[acc].balance<<endl; 
                } 
                else{ 
                    cout<<"INVALID PASSWORD!!"<<endl; 
                } 
            } 
            else{ 
                cout<<"INVALID ACCOUNT NUMBER!!"<<endl; 
            } 
            break; 
             
            case 4: 
            
            cout<<"Enter your account number to withdraw :"; 
            cin>>acc; 
            if(acc<i && acc>0){ 
                cout<<"Enter password :"; 
                cin>>p; 
                if(p==b[acc].password){ 
                    cout<<"Enter the amount to withdraw :"; 
                    cin>>w;
                    if(w<=b[acc].balance){ 
                        b[acc].balance-=w; 
                        cout<<"Your current balance is "<<b[acc].balance<<endl; 
                    } 
                    else{ 
                        cout<<"INSUFFICIANT BALANCE.CANNOT WITHDRAW!!"<<endl; 
                    } 
                } 
                else{ 
                    cout<<"INVALID PASSWORD!!"<<endl; 
                } 
            } 
            else{ 
                cout<<"INVALID ACCOUNT NUMBER!!"<<endl; 
            }
            break; 
             
            case 5: 
            
            cout<<"Enter 'FROM' account number :"; 
            cin>>acc1; 
            cout<<"Enter 'TO' account number :"; 
            cin>>acc2; 
            if((i>acc1 && acc1>0) && (i>acc2 && acc2>0)){ 
                cout<<"Enter password for 'FROM' account:"; 
                cin>>p1; 
                cout<<"Enter password for 'TO' account:"; 
                cin>>p2; 
                if(p1==b[acc1].password && p2==b[acc2].password){ 
                    cout<<"Enter amount to transfer :"; 
                    cin>>t; 
                    if(t<=b[acc1].balance){ 
                        b[acc1].balance-=t; 
                        b[acc2].balance+=t; 
                        cout<<"TRANSFER SUCCESSFULL!!"<<endl; 
                        cout<<"'FROM' account balance : "<<b[acc1].balance<<endl; 
                        cout<<"'TO' account balance : "<<b[acc2].balance<<endl; 
                    } 
                    else{ 
                        cout<<"INSUFFICIANT BALANCE.CANNOT WITHDRAW!!"<<endl; 
                    } 
                } 
                else{ 
                    cout<<"INVALID PASSWORD!!"<<endl; 
                } 
            } 
            else{ 
                cout<<"INVALID ACCOUNT NUMBER!!"<<endl; 
            } 
            break; 
             
            case 6: 
         
            cout<<"Enter your account number to display :"; 
            cin>>acc; 
            if(i>acc && acc>0){ 
                cout<<"Enter password :"; 
                cin>>p; 
                if(p==b[acc].password){ 
                    b[acc].display(); 
                } 
                else{ 
                    cout<<"INVALID PASSWORD!!"<<endl; 
                } 
            } 
            else{ 
                cout<<"INVALID ACCOUNT NUMBER!!"<<endl; 
            } 
            break; 
             
            case 7: 
            for(int j=1; j<i-1; j++){ 
                for(int k=1; k<i-1-j; k++){ 
                    if(b[k].balance>b[k+1].balance){ 
                        temp=b[k+1]; 
                        b[k+1]=b[k]; 
                        b[k]=temp; 
                    } 
                } 
            } 
            for(int z=1; z<i; z++){
                if(b[z].acc_no!=-1){   
                   b[z].display();
                }
            }
            break; 
            
            case 8: 
            int a; 
            cout<<"Enter account number to be deleted :"; 
            cin>>a; 
            if(i>a && a>0){ 
                cout<<"Enter password :"; 
                cin>>p; 
                if(p==b[a].password){ 
                    b[a].Delete(); 
                } 
                else{ 
                    cout<<"INVALID PASSWORD!!"<<endl; 
                } 
            } 
            else{ 
                cout<<"INVALID ACCOUNT NUMBER!!"<<endl; 
            } 
            break; 
             
            case 9:
            cout<<" Thank you..! Please visit again.....!"<<endl;
            exit(0);
            
            break; 
             
            default: 
            cout<<"INVALID CHOICE TRY AGAIN!!"<<endl; 
        }
    }    

}
