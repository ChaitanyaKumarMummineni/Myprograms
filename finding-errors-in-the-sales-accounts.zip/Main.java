/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    public static int Finding_Errors(int N, int M, List<String> Products, List<Float> Product_Prices, List<String> Product_Sold, List<Float> Sold_Price) {
		int errors=0;
		Map<String,Float> prices=new HashMap<>();
		for(int i=0;i<N;i++)
		{
		  prices.put(Products.get(i),Product_Prices.get(i));
		}
		for(int i=0;i<M;i++)
		{
			String Psold=Product_Sold.get(i);
			Float sp=Sold_Price.get(i);
			if(!prices.containsKey(Psold) || !prices.get(Psold).equals(sp))
			{
				errors++;
			}
		}
		return errors;

	}

	public static void main(String[] args) {
	    String[] p={"pencils","pen","rubber"};
		Float [] arr={2.89f,3.29f,5.79f};
		String[] ps={"pencils","pencils","rubber","pen"};
		Float [] arr1={2.89f,2.99f,5.97f,3.29f};
		 System.out.println(Finding_Errors(3,4,Arrays.asList(p),Arrays.asList(arr),Arrays.asList(ps),Arrays.asList(arr1)));
		
	}
}
