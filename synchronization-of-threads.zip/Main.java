/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
class Table{
    synchronized void printTable(int x)
    {
        for(int i=1;i<=5;i++)
        {
            System.out.println(x*i);
            try{
                Thread.sleep(1000);
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
        }
    }
}
class mythread1 extends Thread{
    Table t;
    mythread1(Table t){
        this.t=t;
    }
    public void run()
    {
        t.printTable(5);
    }
}
class mythread2 extends Thread{
    Table t;
    mythread2(Table t){
        this.t=t;
    }
    public void run()
    {
        t.printTable(100);
    }
}
public class Main{
    public static void main(String args [])
    {
        Table obj=new Table();
        mythread1 a=new mythread1(obj);
        mythread2 b=new mythread2(obj);
        a.start();
        b.start();
    }
}