/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
class apple
{

    int a;
    public:
    apple(){
        
    }
    apple(int x)
    {
        a=x;
    }
    apple (apple &c)
    {
        a=c.a;

    }
    void display(){
        cout<<"a:"<<a<<endl;
    }
   
};

int main()
{
    apple a1(5),a3;
    apple a2=a1;
    a1.display();
    a2.display();
    
    

    return 0;
}
