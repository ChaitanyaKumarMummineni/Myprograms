/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
struct PCB{
    int pid,wt,bt,tat;
};
void pline(int x);

int main()
{
    struct PCB p[10],temp;
    int i,j,n,sum=0,w_total=0,t_total=0;
    float t_avg=0.0,w_avg=0.0;
    printf("Enter the number of processes:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
     printf("Enter the burst time of the processes %d:\n",i+1);
     scanf("%d",&p[i].bt);
     p[i].pid=i+1;
    }
    for(i=0;i<n;i++){
        for(j=0;j<n-i-1;j++)
        {
            if(p[j].bt>p[j+1].bt)
            {
                temp=p[j];
                p[j]=p[j+1];
                p[j+1]=temp;
            }
        }
    }
    for(i=0;i<n;i++)
    {
        p[i].wt=sum;
        sum+=p[i].bt;
        p[i].tat=sum;
    }
    pline(55);
    printf("Pid\tBurst\twait\tTurnaround\n");
    pline(55);
    for(i=0;i<n;i++)
    {
       printf("%d\t%d\t%d\t%d\n",p[i].pid,p[i].bt,p[i].wt,p[i].tat);
       w_total+=p[i].wt;
       t_total+=p[i].tat;
    }
    w_avg=w_total/(float)n;
    t_avg=t_total/(float)n;
    printf("The total waiting time:%d\n",w_total);
    printf("The avg wating time:%.3f\n",w_avg);
    printf("The total Turnaround time :%d\n",t_total);
    printf("The average turnaround time:%.3f\n",t_avg);
   
    return 0;
}
void pline(int x)
    {
        for(int i=0;i<x;i++)
        {
            printf("_");
        }
        printf("\n");
    }
