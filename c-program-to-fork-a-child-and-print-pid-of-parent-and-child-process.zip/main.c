/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<unistd.h>
#include<sys/types.h>

int main()
{
  int pid=fork();
  if(pid==0)
  {
      printf("I am child\n");
      printf("Child process id:%d\n",getpid());
  }
  else
  {
      printf("I am parent\n");
      printf("Parent process id:%d\n",getppid());
  }


    return 0;
}
