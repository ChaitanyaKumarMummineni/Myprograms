/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
class M
{
   public:
   int m;
   
   void get_m(int x)
   {
       m=x;
   }
};
class N
{
    public:
    
    int n;
  
    void get_n(int y)
    {
        n=y;
    }
    
};
class P:public M,public N
{
    public:
    void display()
    {
        cout<<"m="<<m<<"\n";
        cout<<"n="<<n<<"\n";
        cout<<"m*n="<<m*n<<"\n";
    }
    
};
int main()
{
   P p1;
   p1.get_m(4);
   p1.get_n(2);
   p1.display();

    return 0;
}
