/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<unistd.h>
#include<sys/wait.h>


int main()
{
    int pid=fork();
    if(pid<0)
    {
        printf("fork failed!");
    }
    else if(pid==0)
    {
        execlp;
    }
    else if(pid>0)
    {
        printf("parent process\n");
        wait;
        printf("child complete");
    }
    return 0;
}
