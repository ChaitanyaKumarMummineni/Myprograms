/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
 struct pcb{
     int pid,at,bt,tat;
 };
 void pline(int x);
int main()
{
    int i,num,j;
    float sum=0.0,avg=0.0;
    struct pcb p[10],temp;
    printf("Enter the total number of processes:");
    scanf("%d",&num);
    for(i=0;i<num;i++)
    {
        printf("Enter the arrival time and the burst time for process %d:\n",i+1);
        scanf("%d%d",&p[i].at,&p[i].bt);
        p[i].pid=i+1;
    }
    for(i=0;i<num-1;i++)
    {
        for(j=0;j<num-i-1;j++)
        {
            if(p[j].at>p[j+1].at)
            {
                temp=p[j];
                p[j]=p[j+1];
                p[j+1]=temp;
            }
        }
    }
    for(i=0;i<num;i++)
    {
        sum=sum+p[i].bt;
        p[i].tat=sum;
    }
    sum=0;
    pline(55);
    printf("pid\tArrival time\tBurst time\tTurnarount time\n");
    pline(55);
    for(i=0;i<num;i++)
    {
        printf("%d\t\t%d\t\t%d\t\t%d\n",p[i].pid,p[i].at,p[i].bt,p[i].tat);
       sum+=p[i].tat;
    }
    pline(55);
    avg=sum/(float)num;
    printf("\nTotal Turnaround time:%f",sum);
    printf("\nAverage Turnaround time:%.3f",avg);
   
    return 0;
}
 void pline(int x)
    {
        for(int i=0;i<x;i++)
        {
            printf("-");
        }
        printf("\n");
    }

