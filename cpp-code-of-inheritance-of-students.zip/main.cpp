//c++ program to demonstate the inheritance
#include <iostream>
#include <string.h>
using namespace std;

class employee
{
    string name;
    int number;
    public:
    void getdata()
    {
        cout<<"Enter the name of Employee:"<<endl;
        cin>>name;
        cout<<"Enter the number:"<<endl;
        cin>>number;
    }
    void putdata()
    {
        cout<<"Name:"<<name<<endl;
        cout<<"Number:"<<number<<endl;
    }
    
};
class manager : public employee
{
    string title;
    double dues;
    public:
    void getdata()
    {
        employee::getdata();
        cout<<"Enter title:"<<endl;
        cin>>title;
        cout<<"Enter the golf dues:"<<endl;
        cin>>dues;
    }
    void putdata()
    {
        employee::putdata();
        cout<<"Title"<<title<<endl;
        cout<<"Golf club dues"<<dues<<endl;
    }
};
    class scientist : public employee
    {
        int publications;
        public:
        void getdata()
        {
            employee::getdata();
            cout<<"Enter the number of publications:"<<endl;
            cin>>publications;
        }
        void putdata()
        {
            employee::putdata();
            cout<<"Number of publications:"<<publications<<endl;
        }
    };
    class labourer: public employee{
        
    };
    

int main()
{
    manager m1,m2;
    scientist s1;
    labourer l1;
    cout<<"Enter the data for  manager 1"<<endl;
    m1.getdata();
    cout<<"Enter the data for  manager 2"<<endl;
    m2.getdata();
    cout<<"Enter the data for scientist 1"<<endl;
    s1.getdata();
    cout<<"Enter the data for labourer 1"<<endl;
    l1.getdata();
    cout<<endl;
    cout<<"Data of manager 1"<<endl;
    m1.putdata();
    cout<<"Data of manager 2"<<endl;
    m2.putdata();
    cout<<"Data of scientist 1"<<endl;
    s1.putdata();
    cout<<"Data of labourer 1"<<endl;
    l1.putdata();
     return 0;
}