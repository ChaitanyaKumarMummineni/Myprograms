# include <stdio.h>
int binarysearch( int arr[], int size,int element)
{
    int low,mid,high;
    low=0;
    high=size-1;
    while(low<high)
    {
        mid=(low+high)/2;
        if(element==arr[mid])
        {
            return mid;
        }
        if(element<mid)
        {
            high=mid-1;
        }
        else
        {
            low=mid+1;
        }
    }
    return -1;
}
int main()
{
    int arr[]={5,6,8,9,10,13,25,36,60};
    int size=sizeof(arr)/sizeof(int);
    int element=36;
    int searchindex=binarysearch(arr,size,element);
    printf("The element %d is found at the index %d",element,searchindex);
}