/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
	public static void main(String[] args) {
		int n,temp,r,sum=0;
		n=1441;
		temp=n;
		while(n>0)
		{
		    r=n%10;
		    sum=(sum*10)+r;
		    n=n/10;
		}
		if(temp==sum)
		{
		    System.out.println("it is a pallindrome");
		}
		else System.out.println("it is not a pallindrome");
	}
}
