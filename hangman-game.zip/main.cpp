#include <iostream>
#include <stdio.h>
#include <string.h>
#include <cstring>
using namespace std;
#define N 9

string arr[N]={"apple","cat","deer","calander","elephant","ball","fall","motercycle","god"};
int strike=6;

int main()
{
   int num=rand()%N;
   cout<<"                            HANGMAN"<<endl;
   cout<<"sorry...!,Here we won't encourage the violence.So the people can't be hanged "<<endl;
   cout<<"YOUR WORD IS :"<<endl;
   int s=0;
   while(arr[num][s]){
       s++;
   }
   char word[s]={};
   for(int i=0; i<s; i++){
       cout<<"_ ";
       word[i]='_';
   }
   cout<<endl;
   while(strike){
       string c;
       int count=0;
       cout<<endl<<"ENTER LETTER :";
       cin>>c;
       for(int i=0; i<s; i++){
           if(c[0]==arr[num][i]){
               word[i]=c[0];
               count++;
           }
       }
       for(int j=0; j<s; j++){
           cout<<word[j]<<" ";
       }
       if(not count){
           strike--;
       }
       cout<<endl;
       cout<<endl;
       cout<<"NUMBER OF STRIKES LEFT ="<<strike<<endl;
       for(int l=0; l<s; l++){
           if(word[l]=='_'){
               continue;
           }
           else{
               break;
           }
       }
   }
   
   if( strike==0){
       cout<<"THE WORD WAS "<<arr[num]<<endl;
   }
   else{
       cout<<"CONGRATULATIONS!! YOU GUESSED IT CORRECTLY."<<endl;
   }
   cout<<endl<<"            GOOD GAME";
}