# include <iostream>
# include <string.h>
using namespace std;
class sec_c 
{
    public:
    int num=9;
    string name="chaitu�";
};
int main()
{
    sec_c c;
    c.num;
    c.name;
    cout<<c.name<<endl;
    cout<<c.num<<endl;
}