#include<iostream>
using namespace std;
enum direction {East, West, North, South};
int main()
{
    direction dir;
   dir = West;
   cout<<dir;
   return 0;
}