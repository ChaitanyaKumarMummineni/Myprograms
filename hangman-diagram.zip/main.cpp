
#include <iostream>

using namespace std;

int main()
{

    cout<<"  __    "<<endl;
    cout<<" |  |   "<<endl;
    cout<<" o  |   "<<endl;
    cout<<"/|\ |   "<<endl;
    cout<<"/ \ |   "<<endl;
    cout<<"________"<<endl;
    return 0;
}