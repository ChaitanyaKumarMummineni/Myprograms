/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using namespace std;

struct student{
    char name[10];
    int roll;
    int total;
    int marks[5];
    int avg;
};

int main(){

    int n;

    cout<<"\n enter the no of student you want to enter: ";
    cin>>n;
    struct student st[n];
    for(int i=0;i<n;i++){

        cout<<"\n Enter the name of student : "<<i+1;
        cin>>st[i].name;
        cout<<"\n Enter the roll no of student : "<<i+1;
        cin>>st[i].roll;
        cout<<"\nenter the marks of 5 subjects  "<<i+1<<endl;
        cin>>st[i].marks[0]>>st[i].marks[1]>>st[i].marks[2]>>st[i].marks[3]>>st[i].marks[4];   
        st[i].total=(st[i].marks[0]+st[i].marks[1]+st[i].marks[2]+st[i].marks[3]+st[i].marks[4]);
        st[i].avg=st[i].total/5;
        

    }
    for (int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            if (st[i].roll>st[j].roll){
                int temp = st[i].roll;
                st[i].roll = st[j].roll;
                st[j].roll=temp;

            }
        }
    }
    for(int i=0;i<n;i++){
        cout<<"\nname of student "<<st[i].name;
        cout<<"\nroll no is "<<st[i].roll;
        cout<<"\ntotal marks is "<<st[i].total;
        cout<<"\navg is "<<st[i].avg<<endl;
    }
    
  
}
