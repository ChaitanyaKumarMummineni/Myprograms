

#include <stdio.h>


struct node
{
    int data;
    struct node*left;
    struct node*right;
};
struct node*createNode(int data)
{
    struct node*n;
    n=(struct node*)malloc(sizeof(struct node));
    n->data=data;
    n->left= Null;
    n->right=Null;
    return n;
}
int main()
{
   struct node*p=createNode(2);
   struct node*p1=createNode(4);
   struct node*p2=createNode(1);
   //Linking the root node with left and right children
   p->left=p1;
   p->right=p2;
   return 0;

    return 0;
}
