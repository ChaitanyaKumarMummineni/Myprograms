
#include <iostream>

using namespace std;
class employee1
{
    protected:
    char name[20];
    int id;
    int grade;
    int basic;
    int da;
    int hra;
    int gross_salary;
    public:
    void get_details();
    int cal_basic(int);
    void cal_gross_sal();
    void display();
};
class employee2:public employee1
{
    float sales;
    public:
    void cal_sal();
};
int main()
{
    employee1 e;
   employee2 ce;
   int choice;
for(;;)
{
    cout<<"1.salary of employee1 \n"<<"2.salary of the employee2\n"<<"3.exit"<<endl;
    cout<<"Enter your choice:"<<endl;
    cin>>choice;
    switch(choice)
    {
        case 1:e.get_details();
        e.cal_gross_sal();
        e.display();
        break;
        case 2:
        ce.get_details();
        ce.cal_sal();
        ce.display();
        break;
        default:exit(0);
        
    }
}
   

    return 0;
}
void employee1::get_details()
 {
        cout<<"name:"<<endl;
        cin>>name;
        cout<<"Id:"<<endl;
        cin>>id;
        cout<<"grade(1-4)"<<endl;
        cin>>grade;
        cout<<"da"<<endl;
        cin>>da;
        cout<<"hra"<<endl;
        cin>>hra;
        
    }
void employee1::cal_gross_sal(){
    basic=cal_basic(grade);
    gross_salary=hra+da+basic;
}
void employee2::cal_sal(){
    float s;
    cout<<"enter sales percentage: "<<endl;
    cin>>sales;
    s=sales/100;
    basic=cal_basic(grade);
    gross_salary=s*(hra+da+basic);
}
int employee1::cal_basic(int grade){
    if(grade==1)
    basic=20000;
    else if(grade==2)
    basic=18000;
    else if(grade==3)
    basic=15000;
    else
    basic=12000;
    return basic;
    
}
void employee1::display(){
    cout<<"name: "<<name<<endl;
        cout<<"id: "<<id<<endl;
            cout<<"grade: "<<grade<<endl;
                cout<<"gross_salary: "<<gross_salary<<endl;
}