/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    public static void revGroup(int arr[],int k)
    {
        int len=arr.length;
        for(int i=0;i<len;i=i+k)
        {
            int start=i;
            int end=Math.min(i+k-1,len-1);
            while(start<=end)
            {
                int temp=arr[start];
                arr[start]=arr[end];
                arr[end]=temp;
                start++;
                end--;
            }
        }
    }
	public static void main(String[] args) {
		System.out.println("Hello World");
		int arr[]={1,9,5,3,7,2,8,3};
		revGroup(arr,3);
		for(int i:arr)
		{
		    System.out.print(i+" ");
		}
	}
}
