
#include <stdio.h>
void selection_sort(int arr[],int n)
{
    for(int i=0;i<n-1;i++)
    {
        int min=i;
        for(int j=i+1;j<n;j++)
        {
            if(arr[j]<arr[min])
            {
                min=j;
                if(min!=i)
                {
                    int temp=arr[i];
                    arr[i]=arr[j];
                    arr[j]=temp;
                }
            }
        }
    }
}
void p_array(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        printf("%d\n",arr[i]);
    }
}
int main()
{
    int arr[]={14,53,2,4,8,9};
    int n=sizeof(arr)/sizeof(arr[0]);
    selection_sort(arr,n);
    p_array(arr,n);

    return 0;
}
