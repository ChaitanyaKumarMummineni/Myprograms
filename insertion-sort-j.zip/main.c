#include<stdio.h>
void insertsort(int arr[],int n)
{
    int i,j,temp;
    for(i=1;i<n;i++)
    {
        temp=arr[i];
        j=i-1;
        while(j>=0&&arr[j]>temp)
        {
            arr[j+1]=arr[j];
            j--;
        }
        arr[j+1]=temp;
    }
}
void array(int arr[],int n)
{
    for(int i=0;i<n;i++)
    {
        printf("%d\n",arr[i]);
    }
}
int main()
{
    int arr[]={4,21,32,25,13};
    int n=sizeof(arr)/sizeof(arr[0]);
    insertsort(arr,n);
    array(arr,n);
    return 0;
    
}