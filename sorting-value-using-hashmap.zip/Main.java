import java.util.*;
public class Main{
    public static void main(String args[])
    {
        Map map=new HashMap();
        map.put("Alliance",200);
        map.put("University",420);
        map.put("chaitanya kumar",047);
        map.entrySet()
        .stream()
        .sorted(Map.Entry.comparingByValue())
        .forEach(System.out::println);
    }
}