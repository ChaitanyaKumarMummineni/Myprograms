# include <iostream>
using namespace std;
void fun(int a)
{
    cout<<"print:"<<a<<endl;
}
void fun(int a,int b)
{
    cout<<"print:"<<a+b;
}
int main()
{
    fun(5);
    fun(4,7);
}