/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{//" it won't run because only the logic is here to solve the arraylist reversing in groups"
    class Solution {
    //Function to reverse every sub-array group of size k.
    void reverseInGroups(ArrayList<Integer> arr, int n, int k) {
        int []a=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=arr.get(i);
        }
        
        for(int i=0;i<n;i=i+k)
        {
            int start=i;
            int end=Math.min(i+k-1,n-1);
            while(start<end)
            {
                int temp = a[start];
                a[start] = a[end];
                a[end] = temp;
                start++;
                end--;
            }
        }
         arr.clear();
        for(int i = 0; i < n; i++){
          arr.add(a[i]);
        }
    }
}
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
}
