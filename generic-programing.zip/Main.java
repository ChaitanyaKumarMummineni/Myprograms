/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

 class sample<T,U>{
	T a;
	U b;
	 sample(T x,U y)
	{
		a=x;
		b=y;
		
	}
	 void display()
	 {
		 System.out.println("a:"+a+"  "+"b:"+b);
	 }
}



public class Main
{
	public static void main(String args[]) {
		
		sample<Integer,String> c=new sample<Integer,String>(3,"chaitu");
		c.display();
	}
}
