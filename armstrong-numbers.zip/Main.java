/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.lang.Math;
public class Main
{
	public static void main(String[] args) {
	    int temp,last=0,digits=0,sum=0;
	    temp=371;
	    while(temp>0)
	    {
	        temp=temp/10;
	        digits++;
	    }
	    temp=371;
	    while(temp>0)
	    {
	        last=temp%10;
	        sum+=Math.pow(last,digits);
	        temp=temp/10;
	    }
	    if(sum==371)
	    {
	        System.out.println("True it is a armstrong Number");
	    }
	    else
	    {
	        System.out.println("False it is not a armstrong number");
	    }
	    
	
	
	}
}
