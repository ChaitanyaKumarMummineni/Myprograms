
#include <stdio.h>
# define N 5
int queue[N];
int front=-1;
int rear=-1;

void enqueue (int x)
{
    if(rear==N-1)
    {
        printf("Queue overflow\n");
    }
    else if(front==-1&&rear==-1)
    {
        front=rear=0;
        queue[rear]=x;
    }
    else
    {
        rear++;
        queue[rear]=x;
    }
}

void dequeue()
{
    if(front==-1&&rear==-1)
    {
        printf("Queue underflow\n");
    }
    else if(front==rear)
    {
        front=rear=-1;
    }
    else
    {
        front++;
    }
}
void display()
{
    if(front==-1&&rear==-1)
    {
        printf("Queue is empty\n");
    }
    else
    {
        for(int i=0;i<rear+1;i++)
        {
            printf(" %d\n",queue[i]);
        }
    }
}
int main()
{
    enqueue(46);
    enqueue(35);
    enqueue(20);
    enqueue(10);
    enqueue(69);
    display();
    enqueue(4);
    dequeue();
    dequeue();
    dequeue();
    dequeue();
    dequeue();
    display();
    dequeue();

    return 0;
}
