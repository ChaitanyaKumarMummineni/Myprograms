#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    char s1[20]="hello";
    char s2[20]="world";
    int a=strlen(s1);
    int b=strlen(s2);
    cout<<a<<endl<<b<<endl;
    strcat(s1,s2);
    cout<<s1 <<endl;
    cout<<s2<<endl;
    strcpy(s1,s2);
    cout<<s1 <<endl<<s2<<endl;
    strcat(s1,s2);
   if(!strcmp(s1,s2)) 
   {
       cout<<" equal";
   }
   else
   {
       cout<<"not equal";
   }
   
   
   
}