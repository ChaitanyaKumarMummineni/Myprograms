/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
struct pcb{
    int pid,wt,bt,rem_bt,tat;
};

int main()
{
    int n,i,j,sq=0,temp,count=0,tq;
    float awt=0,atat=0;
    struct pcb p[10];
    printf("Enter the number of processes:\n");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        printf("Enter the burst time:\n");
        scanf("%d",&p[i].bt);
        p[i].pid=i+1;
        p[i].rem_bt=p[i].bt;
    }
    printf("Enter the time quantum:\n");
    scanf("%d",&tq);
    while(1)
    {
        for(i=0,count=0;i<n;i++)
        {
            temp=tq;
            if(p[i].rem_bt==0)
            {
                count++;
                continue;
            }
            if(p[i].rem_bt>tq)
            {
                p[i].rem_bt=p[i].rem_bt-tq;
            }
            else if(p[i].rem_bt>=0)
                
                {
                    temp=p[i].rem_bt;
                    p[i].rem_bt=0;
                }
                sq=sq+temp;
                p[i].tat=sq;
            
            
        }
        if(n==count)
        break;
    }
    printf("\nprocessId\tbt\t\ttat\twt\t\n");
    for(i=0;i<n;i++)
    {
        p[i].wt=p[i].tat-p[i].bt;
        awt=awt+p[i].wt;
        atat=atat+p[i].tat;
        printf("%d\t\t%d\t\t%d\t%d\n",p[i].pid,p[i].bt,p[i].tat,p[i].wt);
        
    }
    awt=awt/n;
    atat=atat/n;
    printf("Average turn around time :%f\n",atat);
    printf("Average waiting time:%f\n",awt);
    

    return 0;
}
