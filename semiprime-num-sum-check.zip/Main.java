/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
 {
    // function to check if a number is semiprime
    public static boolean isSemiPrime(int n) {
        int cnt = 0;
        for (int i = 2; cnt < 2 && i * i <= n; i++) {
            while (n % i == 0) {
                n /= i;
                cnt++;
            }
        }
        if (n > 1) cnt++;
        return cnt == 2;
    }

    // function to check if a number is the sum of two semiprime numbers
    public static boolean isSumOfSemiPrimes(int n) {
        for (int i = 2; i <= n / 2; i++) {
            if (isSemiPrime(i) && isSemiPrime(n - i)) {
                return true;
            }
        }
        return false;
    }

    // main function to test the above logic
    public static void main(String[] args) {
        int n =30; // change this number to test for a different number
        if (isSumOfSemiPrimes(n)) {
            System.out.println(n + " can be expressed as the sum of two semiprime numbers.");
        } else {
            System.out.println(n + " cannot be expressed as the sum of two semiprime numbers.");
        }
    }


}
// 	public static boolean issemiprime(int n)
// 	{
// 		int cnt=0;
// 		for(int i=2;cnt<2 && i*i<=n;i++)
// 		{
// 			while(n%i==0)
// 			{
// 				n/=i;
// 				cnt++;
// 			}
// 		}
// 		if (n>1) cnt++;
// 		return cnt==2;
// 	}

// 	public static boolean sumOfSemiPrimes(int n) {
// 		for(int i=2;i<=n/2;i++)
// 		{
// 			if(issemiprime(i) && issemiprime(n-i))
// 			{
// 				return true;
// 			}
// 		}
// 		return false;
	
