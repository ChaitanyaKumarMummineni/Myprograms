
#include <stdio.h>
void swap(int *a,int *b)
{
    int temp=*a;
    *a=*b;
    *b=temp;
}
int partition(int a[],int lb,int ub)
{
   int pivot=a[lb];
  int start=lb;
   int end=ub;
    while(start<end)
    {
        while(a[start]<=pivot)
        {
           start++;
        }
        while(a[end]>pivot)
        {
            end--;
        }
        if(start<end)
        {
            swap(&a[start],&a[end]);
        }
    }
    swap(&a[lb],&a[end]);
    return end;
}
void quick_sort(int a[],int lb,int ub)
{
    if(lb<ub)
    { 
        int loc=partition(a,lb,ub);
        quick_sort(a,lb,loc-1);
        quick_sort(a,loc+1,ub);
    }
}
void p_array(int a[],int n)
{
    for(int i=0;i<n;i++)
    {
        printf("%d\n",a[i]);
    }
}
int main()
{
    int a[]={12,32,52,1,2,6};
    int n=sizeof(a)/sizeof(a[0]);
    quick_sort(a,0,n-1);
    p_array(a,n);

    return 0;
}
