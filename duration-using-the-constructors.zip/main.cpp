/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;
class duration
{
    int hours;
    int mins;
    int sec;
    
    public:
    duration()
    {
        hours=0;
        mins=0;
        sec=0;
    }
    duration(int a,int b,int c)
    {
        hours=a;
        mins=b;
        sec=c;
    }
    void getter();
    duration setter(duration);
    void display();
};
void duration::getter()
{
    cout<<"Enter hours,mins,sec"<<endl;
    cin>>hours>>mins>>sec;
}
duration duration::setter(duration d1){
    duration temp;
    temp.mins=mins+d1.mins;
    temp.sec=sec+d1.sec;
    while(temp.sec>=60)
    {
        temp.sec=temp.sec-60;
        temp.mins++;
    }
    while(temp.mins>=60){
        temp.mins=temp.mins-60;
        temp.hours++;
        
    }
    temp.hours+=hours+d1.hours;
    return temp;

}
void duration::display(){
    cout<<"hours"<<hours<<endl;
    cout<<"mins"<<mins<<endl;
    cout<<"sec"<<sec<<endl;
}
int main()
{
   duration d1,d3;
   duration d2(1,1,1);
   d1.getter();
   d3=d2.setter(d1);
   d1.display();
   d2.display();
   d3.display();
    return 0;
}


