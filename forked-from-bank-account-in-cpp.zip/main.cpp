/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;
int n,i,k,m,s;

class bank
{
    int acc_no;
    string name;
    string password;
    int balance;
    
    public:
    bank()
    {
        acc_no=0;
    }
    void create_account();
    void deposit();
    int generate_accno(int i);
    void withdraw();
    void transfer(bank);
    void display();
    static void sort(bank a[]);
    void delete_account();
    
};
int main()
{
  bank b[100];
  cout<<"Enter the number of customer:";
  cin>>n;
  int choice;
  do
  {
      cout<<"1.create account\n 2.display all accounts\n 3.deposit\n 4.withdraw\n 5.transfer\n 6.diaplay based on account number\n 7.sorting based on the balance\n 8.delete account\n 9.exit\n"<<endl;
      cout<<"Enter your choice:"<<endl;
      cin>>choice;
      switch(choice)
      {
          case 1:for(i=0;i<n;i++)
          {
              b[i].create_account();
          }
          break;
          case 2:for(i=0;i<n;i++)
          {
              b[i].display();
          }
          break;
          case 3:cout<<"Enter the account number:"<<endl;
          cin>>k;
          b[k].deposit();
          break;
          case 4:cout<<"Enter the account number:"<<endl;
          cin>>k;
          b[k].withdraw();
          break;
           case 5: cout<<"Enter the from account number:"<<endl;
           cin>>k;
           cout<<"Enter the To account number:"<<endl;
           cin>>m;
           b[k].transfer(b[m]);
           break;
           case 6:cout<<"Enter the account number to display the details:"<<endl;
           cin>>k;
           b[k].display();
           break;
           case 7:bank::sort(b);
           break;
           case 8: cout<<"Enter the account number to delete:"<<endl;
           cin>>k;
           b[k].delete_account();
           break;
           default:exit(0);
          
      }
      cout<<"Press 1 to continue"<<endl;
      cin>>s;
      while(s==1)
      {
          return 0;
      }
  }

}
void bank::create account()
{
    cout<<"Enter"<<i+1<<"customer's details:"<<endl;
    cout<<"name:"<<endl;
    cin>>name;
    acc_no=generate_accno(i);
    cout<<"password:"<<endl;
    cin>>password;
    cout<<"balance:"<<endl;
    cin>>balance;
    
}
 int bank:: generate_accno(int i)
    {
        acc_no=acc_no+i;
        i++;
        return acc_no;
    }
void bank::display()
{
    cout<<"customer details:"<<endl;
    cout<<"name:"<<name<<endl;
    cout<<"account number:"<<acc_no<<endl;
    cout<<"balance:"<<balance<<endl;
}
