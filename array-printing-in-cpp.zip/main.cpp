# include <iostream>
using namespace std;
void array(int arr[],int N)
{
    for (int i=0;i<N;i++)
    {
        cout<<arr[i]<<endl;
    }
}
int main()
{
    int arr[]={3,6,9};
    int N=sizeof(arr)/sizeof(arr[0]);
    array(arr,N);
}