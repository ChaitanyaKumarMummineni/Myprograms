import random
def quicksort(arr,start,stop):
    if start<stop:
        pivotindex=randpartition(arr,start,stop)
        quicksort(arr,start,pivotindex-1)
        quicksort(arr,pivotindex+1,stop)

def randpartition(arr,start,stop):
    randpivot=random.randrange(start,stop)
    arr[start],arr[randpivot]=arr[randpivot],arr[start]
    return partion(arr,start,stop)
    
def partion(arr,start,stop):
    pivot=start
    i=start+1 
    for j in range(start+1,stop+1):
        if arr[j]<=arr[pivot]:
            arr[j],arr[i]=arr[i],arr[j]
            i+=1 
    arr[pivot],arr[i-1]=arr[i-1],arr[pivot]
    pivot=i-1
    return pivot
    
arr=[7,5,2,3,9]
quicksort(arr,0,len(arr)-1)
print(arr)