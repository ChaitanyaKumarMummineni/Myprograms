/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import static java.lang.Math.*;
public class Main
{
	public static void main(String[] args) {
		int a=7,b,sum=0;
		int res;
		while(true)
		{
		  //  b= (int)pow(a,2);
		  
		    b=a*a;
		  //  res= (int)pow((b%10),2);
		  res=(b%10)*(b%10);
		    sum+=res;
		  //  b=b/10;
		  b/=10;
		    if(sum==1)
		    {
		      System.out.println("It's a happy num: "+sum);
		      break;
		    }
		    
		   
		}
	}
}
