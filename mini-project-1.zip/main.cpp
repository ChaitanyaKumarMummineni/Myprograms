#include<iostream>
#include<time.h>
#include<stdlib.h>
using namespace std;
int wallet=0;
int main(){
    cout<<"                                            ***GUESSING THE NUMBER-GAME***  "<<endl;
    cout<<"deposit the money into your wallet"<<endl;
    cin>>wallet;
    while(wallet>0){
        srand(time(0));
        int guess_no,num,bet,check,rnum=rand()%9;
        cout<<"enter the  guessed number"<<endl;
        cin>>guess_no;
        if(guess_no<0 && guess_no>9)
        {
            cout<<"invalid input"<<endl;
           break; 
        }
        cout<<"Enter the betting amount"<<endl;
        cin>>bet;
       if(wallet<bet)
       {
           cout<<"Insufficent wallet amount..!!!"<<endl;
          
       }
       
       
      
        else{
            wallet-=bet;
            if(guess_no==rnum)
            {
               cout<<"Yes! The number was "<<rnum<<endl;
               cout<<"Congratulatin..! You won "<<bet*10<<endl;
               wallet+=bet*10;
               cout<<"Your wallet balance is "<<wallet<<endl;
            }
            else
            {
                cout<<"opps!! You have lost the game"<<endl;
                cout<<"The number was "<<rnum<<endl;
                cout<<"Your current balance in the wallet is "<<wallet<<endl;
            }
            cout<<"Would you like to continue press '1' else '0' "<<endl;
            cin>>check;
            if (check)
            {
                 if(wallet==0)
                {
                   cout<<"Deposit the money into the wallet again..!"<<endl;
                    cin>>wallet;
                }
                else
                {
                    continue;
                }
            }
            else
            {
                cout<<"your balance is "<<wallet<<endl;
                break;
            }
        }
    }
    cout<<"Mummineni Chaitanya kumar"<<endl;
}