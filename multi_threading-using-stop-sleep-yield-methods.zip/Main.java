/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.lang.Thread;
class A extends Thread{
	public void run()
	{
		for(int i=0;i<5;i++) {
			System.out.println("Thread of class A:"+i);
			if(i==3)
			{
				yield();
			
			}
		}
			System.out.println("Thread of class A exits");
	}
}
class B extends Thread{
	public void run()
	{
		for(int i=0;i<5;i++) {
			System.out.println("Thread of class B:"+i);
			if(i==2)
			{
				try{
					sleep(1000);
				}
				catch(Exception e) {
					
				}
			}
				
		}
			System.out.println("Thread of class B exits");
	}
}
class C extends Thread{
	public void run()
	{
		for(int i=0;i<5;i++) {
			System.out.println("Thread of class C:"+i);
			if(i==2)
			{
				
					System.out.println("Thread of class C exits");
				stop();
				
			}
		}
	
	}
}
public class Main {
	public static void main(String args[]) {
		A a=new A();
		B b=new B();
		C c=new C();
		a.start();
		b.start();
		c.start();
	}

}
