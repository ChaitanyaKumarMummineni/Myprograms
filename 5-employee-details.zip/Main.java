/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;

public class Main
{
    public static class Employee{
        public int id;
        public String name;
        public int age;
        public int salary;
        Employee(){}
        Employee(int id,String name,int age,int salary){
            this.id=id;
            this.name=name;
            this.age=age;
            this.salary=salary;
        }
         public void display(){
            System.out.println("ID:"+id);
            System.out.println("Name:"+name);
            System.out.println("Age:"+age);
            System.out.println("Salary:"+salary);
        }
    }
	public static void main(String[] args) {
	    String nm;
	    int id,age,salary;
		Employee[] e= new Employee[5];
		Employee temp=new Employee();
		Scanner sc=new Scanner(System.in);
        for(int i=0; i<5; i++){
            System.out.println("Enter Employee "+(i+1)+" Details:-");
            System.out.print("Enter Id:");
            id=sc.nextInt();
            System.out.print("Enter Name:");
            nm=sc.next();
            System.out.print("Enter Age:");
            age=sc.nextInt();
            System.out.print("Enter Salary:");
            salary=sc.nextInt();
            e[i]=new Employee(id,nm,age,salary);
            System.out.println("");
        }
        for(int i=0; i<5; i++){
            for(int j=0; j<5-i-1; j++){
                if(e[j].id>e[j+1].id){
                    temp=e[j];
                    e[j]=e[j+1];
                    e[j+1]=temp;
                }
            }
        }
        System.out.println("Sorted list of Employees based on their ID's:-");
        for(int i=0; i<5; i++){
            System.out.println("Employee "+(i+1)+" Details:-");
            e[i].display();
            System.out.println("");
        }
        int max=e[0].salary,min=e[0].salary,c=0;
        System.out.println("Employee Details with highest Salary:-");
        for(int i=0; i<5; i++){
            if(e[i].salary>max){
                max=e[i].salary;
                c=i;
            }
        }
        e[c].display();
        System.out.println("");
        System.out.println("Employee Details with lowest Salary:-");
        for(int i=0; i<5; i++){
            if(e[i].salary<min){
                min=e[i].salary;
                c=i;
            }
        }
        e[c].display();
        
	}
}
