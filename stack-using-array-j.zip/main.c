# include <stdio.h>
# define N 6
int stack[N];
int top=-1;
void push(int x)
{

    if(top==N-1)
    {
        printf("stack overflow");
    }
    else
    {
        top++;
        stack[top]=x;
        printf("%d is inserted\n",x);
        
    }
}
 void pop()
{

    if(top==-1)
    {
        printf("stack underflow");
    }
    else
    {
        printf("%d is deleted\n",stack[top]);
        top--;
        
    }
}
void peek()
{
    if(top==-1)
    {
        printf("stack is empty");
    }
    else
    {
        printf("%d\n",stack[top]);
    }
}
 void display()
{  int i;
    for( i=0; i<=top;i++)
    {
    printf("%d ",stack[i]);
    
    }
}
int main(){
   
    push(1);
    push(2);
    push(5);
    pop();
    peek();
    display();
 
}
