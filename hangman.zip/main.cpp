#include <iostream>
#include <stdio.h>
#include <string.h>
#include <cstring>
#include <time.h>
using namespace std;
#define N 9
string arr[N]={"bat","apple","cat","donkey","elephant","fan","goat","hat","bucket"};
int strike=5;
int main()
{
   srand(time(0)); 
   int num=rand()%N;
   cout<<"     ***HANGMAN***     "<<endl;
   cout<<"                             by-NITISH"<<endl;
   cout<<"YOUR WORD IS :"<<endl;
   int s=0;
   while(arr[num][s]){
       s++;
   }
   char word[s]={};
   for(int i=0; i<s; i++){
       cout<<"_ ";
       word[i]='_';
   }
   cout<<endl;
   while(strike){
       string h;
       int ct=0;
       cout<<endl<<"ENTER LETTER :";
       cin>>h;
       for(int i=0; i<s; i++){
           if(h[0]==arr[num][i]){
               word[i]=h[0];
               ct++;
           }
       }
       for(int j=0; j<s; j++){
           cout<<word[j]<<" ";
       }
       if(not ct){
           strike--;
       }
       cout<<endl;
       cout<<endl;
       cout<<"NUMBER OF STRIKES LEFT ="<<strike<<endl;
       int ct1=0;
       for(int l=0; l<s; l++){
           if(word[l]=='_'){
               ct1++;
           }
       }
       if(not ct1){
           break;
       }
   }
      int tr=0;
   for(int k=0; k<s; k++){
       if(word[k]=='_'){
           tr=1;
           break;
       }
   }
   
   if(tr){
       cout<<"THE WORD WAS "<<arr[num]<<endl;
       cout<<"YOU LOST THE GAME "<<endl;
       cout<<"YOU ARE KILLED"<<endl;
    cout<<"   ____   "<<endl;
    cout<<"  |    |   "<<endl;
    cout<<"  o    |   "<<endl;
    cout<<"|_|_|  |   "<<endl;
    cout<<" _|_   |   "<<endl;
    cout<<" | |   |"    <<endl;
    cout<<"_______|"<<endl;
    cout<<"   :-(   "<<endl;
    
    return 0;
   }
   else{
       cout<<"CONGRATULATIONS!! YOU GUESSED IT RIGHT."<<endl;
   }
   cout<<endl<<"            GOOD GAME";}
