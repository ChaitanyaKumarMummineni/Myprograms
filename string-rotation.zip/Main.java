/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    	public static String  rotationOfStrings (String str1, String str2){
	int	l=str1.length();

	String s="";
		for(int i=0;i<l;i++)
		{
		    s = str1.substring(i) + str1.substring(0, i);
		        if(s.equals(str2)){
		        System.out.println(s);
		        break;
		        }
		    
		   
		}
		        if(s.equals(str2))
	        	{
	        	   
		           return (str2+"yes");
	        	}
		        else{
		            return (str2+"no");
	            	}
		
    }
	public static void main(String[] args) {
		System.out.println(rotationOfStrings("abcd","bcda"));
	}
}
