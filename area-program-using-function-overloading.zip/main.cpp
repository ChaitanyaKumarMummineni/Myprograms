/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
#include <math.h>
#define pi 3.14
using namespace std;
void area();
void area(int);
void area(int,int);
void area(float);
int main()
{
   int choice;
   int l,b,s,h;
   float r;
   for(;;)
   {
       cout<<endl;
       cout<<"1.Area of the rectange\n2.Area of square\n3.Area of triangle\n4.Area of the circle\n"<<endl;
       cout<<"Enter your choice :";
       cin>>choice;
       switch(choice)
       {
           case 1:
           area();
           break;
           case 2:
           cout<<"Enter the side :";
           cin>>s;
           area(s);
           break;
           case 3:
           cout<<"Enter the base :";
           cin>>b;
           cout<<"Enter the height :";
           cin>>h;
           area(b,h);
           break;
           case 4:
           cout<<"Enter the radius :";
           cin>>r;
           area(r);
           break;
           default:
           exit(0);
       }
   }
   return 0;
}
void area()
{
    int l,b;
    cout<<"Enter the length :";
    cin>>l;
    cout<<"Enter the breath :";
    cin>>b;
    cout<<"Area of the rectangle is :"<<l*b<<endl;
}
void area(int s)
{
    cout<<"Area of the square is:"<<s*s<<endl;;
}
void area(int b,int h)
{
    cout<<"Area of the triangle is:"<<0.5*b*h<<endl;
}
void area(float r)
{
    cout<<"Area of the circle is :"<<ceil(pi*r*r)<<endl;
}