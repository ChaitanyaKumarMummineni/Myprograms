

#include <iostream>
#include <string.h>
using namespace std;
class student
{ 
    public:
    int reg,age;
    char name[20];
    
    void getdata()
    {
        cout<<"Enter the student registration,age,name"<<endl;
        cin>>reg>>age;
        cin>>name;
    }
    //  void putdata()
    // {
    //     cout<<"student name:"<<name<<endl<<"Registration no:"<<reg<<endl<<"Age:"<<age<<endl;
    // }
};
class ugstudent: public student
{
     public:
    int stipend,sem;
    float fees;
   
    void getdata()
    {
        student::getdata();
        cout<<"Enter the ugstudent stipend,sem,fees"<<endl;
        cin>>stipend>>sem>>fees;
    }
   
};
class pgstudent : public student{
    public:
    int stipend,sem;
    float fees;
    
    void getdata()
    {
        student::getdata();
        cout<<"Enter the pgstudent stipend,sem,fees"<<endl;
        cin>>stipend>>sem>>fees;
    }
};
int main()
{
    
   ugstudent ug[20];
   pgstudent pg[20];
   
   
   int i,n,m;
   float average;
   cout<<"Enter the no.of entries in the ugstudent class:";
   cin>>n;
   for(i=1;i<=n;i++)
   {
       ug[i].getdata();
       for(int sem=1;sem<=8;sem++)
       {
           float sum=0;
           int found=0,count=0;
           for(i=1;i<=0;i++)
           {
               if(ug[i].sem==sem)
               {
                   sum=sum+ug[i].age;
                   found=1;
                   count++;
               }
           }
           if (found=1)
           {
             average=sum/count;
             cout<<"\nAverage of age of sem "<<sem<<"is"<<average;
              
           }
       }
   }
     cout<<"Enter the no.of entries in the pgstudent class:";
   cin>>n;
   for(i=1;i<=n;i++)
   {
       pg[i].getdata();
       for(int s=1;s<=8;s++)
       {
           float sum=0;
           int found=0,count=0;
           for(i=1;i<=n;i++)
           {
               if(pg[i].sem==s)
               {
                   sum=sum+pg[i].age;
                   found=1;
                   count++;
               }
           }
           if (found==1)
           {
             average=sum/count;
             cout<<"\nAverage of age of sem: "<<s<<"is"<<average;
              
           }
       }
   }

    return 0;
}

