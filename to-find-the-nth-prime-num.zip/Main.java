/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    public static int myfun(int n)
    {
         int count=0,flag=0;
	    
	    for(int i=2;i>0;i++)
	    {
	       
	        flag=0;
	        
	        for(int j=2;i>j;j++)
	        {
	            if(i%j==0)
	            {
	                flag=1;
	                break;
	            }
	        }
	        if(flag==0)
	        {
	            count++;
	            
	        }
	        if(count==n){
	            return i;
	        }
	    }
	    return 0;
	    

	
    }
	public static void main(String[] args) {
	    System.out.println(myfun(3));
	    
	}
	   
	
	
}
