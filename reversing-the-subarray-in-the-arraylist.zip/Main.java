/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    	public static List<Integer> ArrayOperations(List<Integer> Arr, List<Integer> Queries) {
    	    int n=Arr.size();
		int m=Queries.size()/2;
		for(int i=0;i<m;i++){
			int l=Queries.get(2*i);
			int r=Queries.get(2*i+1);
			while(l<r)
			{
				int temp=Arr.get(l);
				Arr.set(l,Arr.get(r));
				Arr.set(r,temp);
				l++;
				r--;
			}
		}
		return Arr;
	}
	public static void main(String[] args) {
	    List<Integer> a=new ArrayList<>();
	    a.add(5);
	    a.add(3);
	    a.add(2);
	    a.add(1);
	    a.add(3);
	    List<Integer> b=new ArrayList<>();
	    b.add(0);
	    b.add(1);
	    b.add(1);
	    b.add(3);
		System.out.println(ArrayOperations(a,b));
	}
}