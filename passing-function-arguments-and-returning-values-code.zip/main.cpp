
#include <iostream>
using namespace std;
 int fun(int a,int b)
{
    return a+b;
}
int main()
{
    int c;
    c=fun(1,2);
    cout<<c;


    return 0;
}
