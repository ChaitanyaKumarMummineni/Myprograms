/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define N 5
int main(){
    int p[N]={1,2,3,4,5};
    int block_size[N]={300,50,200,350,70};
    int process_size[N]={200,47,212,426,10};
    int allocated[N];
    for(int i=0; i<N; i++){
        allocated[i]=-1;
    }
    for(int i=0; i<N; i++){
        for(int j=i; j<2*N; j++){
            if(allocated[j%N]==-1 && process_size[i]<=block_size[j%N]){
                allocated[i]=j%N+1;
                break;
            }
        }
    }
    printf("BlockSize ProcessSize AllocatedProcess\n");
    for(int i=0; i<N; i++){
        if(allocated[i]!=-1){
            printf("%d\t%d\t%d\t\n",block_size[i],process_size[i],allocated[i]);
        }
        else{
            printf("%d\t%d\tNot Allocated\n",block_size[i],process_size[i]);
        }
    }
}