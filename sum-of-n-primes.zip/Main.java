/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{
    	public static boolean isprime(int num)
	{  
	     if(num<2)
	     {
	     	return false;
	     }
	     for(int i=2;i<=Math.sqrt(num);i++)
	     {
	     	if(num%i==0)
	     	{
	     		return false;
	     	}
	     }
	     return true;
	}

	public static int sumOfPrimes(int n) {
		int count=0,sum=0,num=2;
		
			while(count<n)
			{
				if(isprime(num))
			 {
				sum+=num;
				count++;
				
			 }
			 num++;
			}
		
		return sum;
	}
	public static void main(String[] args) {
		System.out.println(sumOfPrimes(2));
		
	}
}
