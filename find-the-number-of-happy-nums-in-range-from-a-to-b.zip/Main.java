/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main{
	public static boolean ishappynum(int num)
	{
		int rem=0,sum=0;
		while(num>0)
		{
			rem=num%10;
			sum+=rem*rem;
			num/=10;
		}
			if(sum==1)
			{
				return true;
			}
			else if(sum==4){
				return false;
			}
			else 
			return(ishappynum(sum));
	}

	public static int happyNumbers(int n1, int n2) {
		int count=0;
		
		for(int i=n1;i<=n2;i++)
		{
		  if(ishappynum(i))
		  {
		  	count++;
		  }
		}
		return count;
		
	}

	public static void main(String[] args) {
	
		System.out.println(happyNumbers(1, 10));
	}
}