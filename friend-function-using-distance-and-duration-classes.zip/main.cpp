# include <iostream>
using namespace std;
class Duration;
class Distance
{
    int feet;
    int inches;
    public:
    void read()
    { cout<<"Enter the distance:"<<endl;
        cin>>feet;
        cin>>inches;
    }
    void display()
    {
        cout<<"feet:"<<feet<<endl;
        cout<<"inches:"<<inches<<endl;
    }
    friend void calculate(Distance,Duration);
};
class Duration
{
    int hours;
    int mins;
    int secs;
    public:
    void read()
    {cout<<"Enter the time:"<<endl;
       cin>> hours;
        cin>>mins;
        cin>>secs;
    }
    void display(){
        cout<<"hours:"<<hours<<endl;
        cout<<"mins:"<<mins<<endl;
        cout<<"secs:"<<secs<<endl;
    }
    friend void calculate(Distance,Duration);
    
};
void calculate(Distance d1,Duration d2){
    while(d1.inches>=12)
    {
        d1.feet++;
        d1.inches=d1.inches-12;
        
    }
    d1.display();
    while(d2.secs>=60)
    {
        d2.mins++;
        d2.secs=d2.secs-60;
    }
    while(d2.mins>=60)
    {
        d2.hours++;
        d2.mins=d2.mins-60;
    }
    d2.display();
}
int main()
{
    Distance d1;
    Duration d2;
    d1.read();
    d2.read();
    calculate(d1,d2);
}