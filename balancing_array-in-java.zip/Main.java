/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    	public static int balancing_array(List<Long> Arr) {
    	    Long lsum=0l;
    	    int l=Arr.size();
    	    Long rsum=Arr.get(l-1);
    	    int j=l-1,pivot=0;
    	    int flag=1;
    	    while(flag==1){
    	
    	        for(int i=0;i<l&&i<j;i++)
    	    {
    	        System.out.println("i"+i);
    	        lsum+=Arr.get(i);
    	        System.out.println("lsum:"+lsum);
    	   
    	        System.out.println("rsum:"+rsum);
    	        if(lsum==rsum)
    	        {
    	            pivot=i+1;
    	            flag=0;
    	            break;
    	            
    	            
    	        }
    	        
    	    }
    	    lsum=0l;
    	    j--;
    	    rsum=rsum+Arr.get(j);
    	    System.out.println(rsum);
    	    
    	    }
    	        
	        	return pivot;

	}
	public static void main(String[] args) {
		ArrayList<Long> arr=new ArrayList<>();
		arr.add(5l);
		arr.add(2l);
		arr.add(3l);
		arr.add(2l);
		arr.add(4l);
		arr.add(6l);
		System.out.println(balancing_array(arr));
	}
}
