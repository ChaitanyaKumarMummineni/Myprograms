# include<iostream>
using namespace std;
class item
{
    int count;
    public:
    void read ()
    {
       count=10;
    }
    void display()
    {
        cout<<count<<endl;
    }
};
int main()
{
    item p ;
   item*a=&p;
   a->read();
   a->display();
}